let handler = async (m, { conn }) => {
	
	m.reply('Ya Gapapa Sayang, Jangan Di Ulangin Ya..❤')
	
}


handler.command = /^(maaf)$/i

export default handler
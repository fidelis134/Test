let handler = async (m, { conn, usedPrefix, command }) => {
let who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.fromMe ? conn.user.jid : m.sender
let name = conn.getName(who)
  conn.sendButton(m.chat, `Cih Dasar Sangean`, wm, pickRandom(femdom), [['\nJadi Sange :v', `huuu`]],m)
}
handler.help = ['femdom']
handler.tags = ['nsfw','premium']
handler.command = /^(femdom)$/i

handler.premium = true

export default handler

function pickRandom(list) {
  return list[Math.floor(list.length * Math.random())]
}

const femdom = [

 "https://media.discordapp.net/attachments/516059858924208138/681659736759861318/image0_6.jpg",
    "https://media.discordapp.net/attachments/516059858924208138/681658400810991650/lusciousnet_lusciousnet_hentai-a-small-facesitting-album-x-p_160480173_1.jpg",
    "https://media.discordapp.net/attachments/516059858924208138/679172636252700692/5d63377e84f7d.jpeg",
    "https://media.discordapp.net/attachments/516059858924208138/678115448344018944/image0.jpg",
    "https://media.discordapp.net/attachments/516059858924208138/677623452538241050/4e98dcbfed1201003cd6f481ad58e311.jpg",
    "https://media.discordapp.net/attachments/516059858924208138/677254777180127243/camilla-hentai-1.jpg",
    "https://media.discordapp.net/attachments/516059858924208138/677054546278613004/481lf0qukyb31.jpg",
    "https://media.discordapp.net/attachments/516059858924208138/676001334482173972/image0.jpg",
    "https://media.discordapp.net/attachments/516059858924208138/674625128616689671/image0.jpg",
    "https://media.discordapp.net/attachments/516059858924208138/672517231745433641/571b3b0a489c325e0aefd6bf4f000c92.png",
    "https://media.discordapp.net/attachments/516059858924208138/672517231313289216/336aeae234bf6b53225c626361ac9067.png",
    "https://media.discordapp.net/attachments/516059858924208138/671022545390141440/image0.jpg",
    "https://media.discordapp.net/attachments/516059858924208138/669051142046482455/chcomic.png",
    "https://media.discordapp.net/attachments/516059858924208138/669051124610891796/cutewship2.jpg",
    "https://media.discordapp.net/attachments/516059858924208138/667061547142610945/image3.png",
    "https://media.discordapp.net/attachments/516059858924208138/666665636306485280/image0-5.jpg",
    "https://media.discordapp.net/attachments/516059858924208138/666665577275981834/image0-3.jpg",
    "https://media.discordapp.net/attachments/516059858924208138/666306387659456512/4dfa85.jpg",
    "https://media.discordapp.net/attachments/516059858924208138/666071339555356683/IMG_20190724_092936.jpg",
    "https://media.discordapp.net/attachments/516059858924208138/665938875524317184/image1-1-1.jpg",
    "https://media.discordapp.net/attachments/516059858924208138/665882446725906442/Screenshot_20190924-075728_Discord.jpg",
    "https://media.discordapp.net/attachments/516059858924208138/665678391495753758/image3-1.jpg",
    "https://media.discordapp.net/attachments/516059858924208138/665308716056444957/image0-7.jpg",
    "https://media.discordapp.net/attachments/516059858924208138/664155658140123156/Litchipix-628467-femdom_handjob.jpg",
    "https://media.discordapp.net/attachments/516059858924208138/663015503815507978/9578efa.jpg",
    "https://media.discordapp.net/attachments/516059858924208138/662081719385718786/6a8ae79.png",
    "https://media.discordapp.net/attachments/516059858924208138/661640081060397086/f693a9683b409df100514296dd9b6fcb.jpg",
    "https://media.discordapp.net/attachments/516059858924208138/661638128964075520/5d2d41181dc0c75337b431952aedf734.jpg",
    "https://media.discordapp.net/attachments/516059858924208138/661638125352648709/IMG_20191202_221150.jpg",
    "https://media.discordapp.net/attachments/516059858924208138/661637986831695882/69674763_p2_master1200.jpg",
    "https://media.discordapp.net/attachments/516059858924208138/661637985594507307/hk416_and_ump45_girls_frontline_drawn_by_beluga_dolphin__sample-bfbbb30c37f0adaa34af976a9f918ebb.jpg",
    "https://media.discordapp.net/attachments/516059858924208138/661637985166557196/f21.png",
    "https://media.discordapp.net/attachments/516059858924208138/661637984654721045/1560099824154.png",
    "https://media.discordapp.net/attachments/516059858924208138/661637984654721044/lusciousnet_lusciousnet_1453086825996_2049130559_01C0YXDYVXDQ9B58RAXZMTDZXR.png",
    "https://media.discordapp.net/attachments/516059858924208138/660791681620246554/tumblr_phdy21Ypw61v73vj5_1280.jpg",
    "https://media.discordapp.net/attachments/516059858924208138/660520486996017172/tumblr_o2cy4jjOVE1v5h9coo1_500.png",
    "https://media.discordapp.net/attachments/516059858924208138/660250656476758035/1567518493520.jpg",
    "https://media.discordapp.net/attachments/516059858924208138/659691562158260224/1253c9.jpg",
    "https://media.discordapp.net/attachments/516059858924208138/658471323034583050/tumblr_oxxvbjN5qA1tm1dgio1_540.png",
    "https://media.discordapp.net/attachments/516059858924208138/658439955344916488/D12YGbcUgAAWkHT.jpg",
    "https://media.discordapp.net/attachments/516059858924208138/651178121193586689/image0-6.jpg",
    "https://media.discordapp.net/attachments/516059858924208138/650617998717091856/mcjtmzwzj0m31.png",
    "https://media.discordapp.net/attachments/516059858924208138/650617985689583617/kniqtktx3sp31.jpg",
    "https://cdn.discordapp.com/attachments/770948564947304448/771016911948611624/1728-J6EgZMRLOYs.jpg",
    "https://cdn.discordapp.com/attachments/770948564947304448/771023805438623784/Hentai_Nation_592.jpg"
]
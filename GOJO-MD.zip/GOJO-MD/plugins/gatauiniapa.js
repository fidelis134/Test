let handler = async (m, { conn }) => {
	
	m.reply('Sama Sama Sayang ❤')
	
}


handler.command = /^(makasih)$/i

export default handler